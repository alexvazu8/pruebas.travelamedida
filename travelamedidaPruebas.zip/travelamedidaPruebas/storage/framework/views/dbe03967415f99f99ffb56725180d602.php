<?php $__env->startSection('template_title'); ?>
    Reservas
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="row">
            <div class="col-sm-12">
                <div class="card">
                    <div class="card-header">
                        <div style="display: flex; justify-content: space-between; align-items: center;">

                            <span id="card_title">
                                <?php echo e(__('Reservas')); ?>

                            </span>
                        </div>
                    </div>
                    <?php if($message = Session::get('success')): ?>
                        <div class="alert alert-success m-4">
                            <p><?php echo e($message); ?></p>
                        </div>
                    <?php endif; ?>

                    <div class="card-body bg-white">
                        <div class="table-responsive">
                            <table class="table table-striped table-hover">
                                <thead class="thead">
                                    <tr>
                                        <th>No</th>
                                        
									<th >Localizador</th>
                                    <th >Creacion</th>
									<th >Importe Reserva</th>
									<th >Nombre Cliente</th>
									<th >Email Contacto Reserva</th>
									<th >Comentarios</th>
									<th >Nombre Usuario</th>

                                        <th></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    //print_r($reservas);
                                    ?>
                                    <?php $__currentLoopData = $reservas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reserva): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e(++$i); ?></td>
                                            
										<td ><?php echo e($reserva->Localizador); ?></td>
                                        <td ><?php echo e($reserva->created_at->format('d/m/Y')); ?></td>
										<td ><?php echo e($reserva->Importe_Reserva); ?></td>
										<td ><?php echo e($reserva->Nombre_Cliente); ?> <?php echo e($reserva->Apellido_Cliente); ?></td>
										<td ><?php echo e($reserva->Email_contacto_reserva); ?></td>
										<td ><?php echo e($reserva->Comentarios); ?></td>
										<td ><?php echo e($reserva->user->name); ?></td>

                                            <td>                                                
                                                <a class="btn btn-sm btn-primary " href="<?php echo e(route('reservas.showReserva', $reserva->Localizador)); ?>"><i class="fa fa-fw fa-eye"></i> <?php echo e(__('Show')); ?></a>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                <?php echo $reservas->withQueryString()->links(); ?>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\travelamedida\resources\views/reserva/index.blade.php ENDPATH**/ ?>