<?php $__env->startSection('content'); ?>
<div class="welcome-container">
    <!-- Hero Section -->
    <section class="hero-section">
        <div class="hero-content">
            <h1 class="hero-title">Bienvenido a <?php echo e(config('app.name', 'Travel Experience')); ?></h1>
            <p class="hero-subtitle">Descubre experiencias únicas con nuestros traslados, hoteles y tours exclusivos</p>
            
            <div class="hero-actions">
                <a href="<?php echo e(url('/traslados')); ?>" class="btn btn-primary btn-hero">
                    <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                        <path d="M8 16.5a1.5 1.5 0 11-3 0 1.5 1.5 0 013 0zM15 16.5a1.5 1.5 0 11-3 0 1.5 1.5 0 013 0z" />
                        <path d="M3 4a1 1 0 00-1 1v10a1 1 0 001 1h1.05a2.5 2.5 0 014.9 0H10a1 1 0 001-1v-1h.05a2.5 2.5 0 014.9 0H19a1 1 0 001-1v-2a1 1 0 00-.293-.707l-3-3A1 1 0 0016 7h-1V5a1 1 0 00-1-1H3z" />
                    </svg>
                    Traslados
                </a>
                <a href="<?php echo e(url('/hoteles')); ?>" class="btn btn-secondary btn-hero">
                    <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                        <path fill-rule="evenodd" d="M5.05 4.05a7 7 0 119.9 9.9L10 18.9l-4.95-4.95a7 7 0 010-9.9zM10 11a2 2 0 100-4 2 2 0 000 4z" clip-rule="evenodd" />
                    </svg>
                    Hoteles
                </a>
                <a href="<?php echo e(url('/tours')); ?>" class="btn btn-outline btn-hero">
                    <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                        <path fill-rule="evenodd" d="M6 6V5a3 3 0 013-3h2a3 3 0 013 3v1h2a2 2 0 012 2v3.57A22.952 22.952 0 0110 13a22.95 22.95 0 01-8-1.43V8a2 2 0 012-2h2zm2-1a1 1 0 011-1h2a1 1 0 011 1v1H8V5zm1 5a1 1 0 011-1h.01a1 1 0 110 2H10a1 1 0 01-1-1z" clip-rule="evenodd" />
                        <path d="M2 13.692V16a2 2 0 002 2h12a2 2 0 002-2v-2.308A24.974 24.974 0 0110 15c-2.796 0-5.487-.46-8-1.308z" />
                    </svg>
                    Tours
                </a>
            </div>
        </div>
        
        <div class="hero-image">
            <img src="<?php echo e(asset('images/banner.jpg')); ?>" alt="Experiencias de viaje" class="img-hero">
        </div>
    </section>

    <!-- Features Section -->
    <section class="features-section">
        <h2 class="section-title">¿Por qué elegirnos?</h2>
        <div class="features-grid">
            <div class="feature-card">
                <div class="feature-icon">
                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                    </svg>
                </div>
                <h3>Rápido</h3>
                <p>Reservas instantáneas y confirmación inmediata</p>
            </div>
            
            <div class="feature-card">
                <div class="feature-icon">
                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" />
                    </svg>
                </div>
                <h3>Seguro</h3>
                <p>Protección de datos y pagos 100% seguros</p>
            </div>
            
            <div class="feature-card">
                <div class="feature-icon">
                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 10h18M7 15h1m4 0h1m-7 4h12a3 3 0 003-3V8a3 3 0 00-3-3H6a3 3 0 00-3 3v8a3 3 0 003 3z" />
                    </svg>
                </div>
                <h3>Flexible</h3>
                <p>Cancelación segun las politicas de cada servicio</p>
            </div>
            
            <div class="feature-card">
                <div class="feature-icon">
                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 8h2a2 2 0 012 2v6a2 2 0 01-2 2h-2v4l-4-4H9a1.994 1.994 0 01-1.414-.586m0 0L11 14h4a2 2 0 002-2V6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2v4l.586-.586z" />
                    </svg>
                </div>
                <h3>Soporte 24/7</h3>
                <p>Asistencia en múltiples idiomas cuando lo necesites</p>
            </div>
        </div>
    </section>

    <!-- Popular Destinations -->
    <section class="destinations-section">
        <h2 class="section-title">Destinos populares</h2>
        <div class="destinations-grid">
            <div class="destination-card">
                <img src="<?php echo e(asset('images/destination1.jpg')); ?>" alt="Samaipata">
                <div class="destination-overlay">
                    <h3>Fuerte de Samaipata</h3>
                    <a href="#" class="btn btn-outline">Explorar</a>
                </div>
            </div>
            
            <div class="destination-card">
                <img src="<?php echo e(asset('images/destination2.jpg')); ?>" alt="Santa Cruz de la Sierra">
                <div class="destination-overlay">
                    <h3>Santa Cruz</h3>
                    <a href="#" class="btn btn-outline">Explorar</a>
                </div>
            </div>
            
            <div class="destination-card">
                <img src="<?php echo e(asset('images/destination3.jpg')); ?>" alt="Salar de Uyuni">
                <div class="destination-overlay">
                    <h3>Uyuni</h3>
                    <a href="#" class="btn btn-outline">Explorar</a>
                </div>
            </div>
        </div>
    </section>

    <!-- Testimonials -->
    <section class="testimonials-section">
        <h2 class="section-title">Lo que dicen nuestros clientes</h2>
        <div class="testimonials-slider">
            <div class="testimonial-card">
                <div class="testimonial-content">
                    <div class="testimonial-rating">
                        ★★★★★
                    </div>
                    <p>"Excelente servicio desde el primer momento. Los traslados fueron puntuales y los hoteles superaron nuestras expectativas."</p>
                </div>
                <div class="testimonial-author">
                    <img src="<?php echo e(asset('images/user1.jpg')); ?>" alt="María González">
                    <div>
                        <h4>María González</h4>
                        <span>Viajó a Santa Cruz</span>
                    </div>
                </div>
            </div>
            
            <div class="testimonial-card">
                <div class="testimonial-content">
                    <div class="testimonial-rating">
                        ★★★★☆
                    </div>
                    <p>"Los tours fueron increíbles, especialmente el de ruinas del Fuerte. Los guías muy profesionales y conocedores."</p>
                </div>
                <div class="testimonial-author">
                    <img src="<?php echo e(asset('images/user2.jpg')); ?>" alt="Carlos Martínez">
                    <div>
                        <h4>Carlos Martínez</h4>
                        <span>Viajó a Samaipata</span>
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\travelamedida\resources\views/welcome.blade.php ENDPATH**/ ?>