

<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>Respuestas de Reservas</h1>
    <?php if(isset($respuestas['error'])): ?>
    <?php 
    print_r($respuestas);
    ?>
          <?php echo e($respuestas['error']); ?>

          <a href="<?php echo e(url('/carritos/show')); ?>" class="btn btn-primary btn-lg mx-2">Retornar al Carrito</a>
    <?php else: ?>
        Hay un Error
        <?php if(isset($mensaje)): ?>
         <?php echo e($mensaje); ?>

        <?php endif; ?>
        <a href="<?php echo e(url('/carritos/show')); ?>" class="btn btn-primary btn-lg mx-2">Retornar al Carrito</a>
        
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\travelamedida\resources\views/reservas/error.blade.php ENDPATH**/ ?>