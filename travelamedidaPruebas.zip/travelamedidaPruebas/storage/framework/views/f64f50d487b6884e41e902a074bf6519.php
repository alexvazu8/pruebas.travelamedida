

<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>Respuestas del Traslado</h1>
    <?php
    //print_r($respuestas);
    ?>
    <?php if(empty($respuestas)): ?>
    <p>No hay respuestas para mostrar</p>
    <a href="<?php echo e(url('/traslados')); ?>" class="btn btn-primary btn-lg mx-2">Traslados</a>
    <?php else: ?>
        <?php if(isset($respuestas['error'])): ?>
            <?php echo e($respuestas['error']); ?>

            <?php if(isset($respuestas['validation_errors'])): ?>
                <?php $__currentLoopData = $respuestas['validation_errors']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php $__currentLoopData = $error; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detelle_error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <p><?php echo e($detelle_error); ?></p>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
            <a href="<?php echo e(url('/traslados')); ?>" class="btn btn-primary btn-lg mx-2">Traslados</a>
        <?php else: ?>
            <p> <strong>Error no  detectado.</strong> </p>
            <a href="<?php echo e(url('/traslados')); ?>" class="btn btn-primary btn-lg mx-2">Traslados</a>
        <?php endif; ?>
    <?php endif; ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\travelamedida\resources\views/traslados/errorRespuestas.blade.php ENDPATH**/ ?>