

<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>Respuestas del Traslado</h1>
    <?php
    //print_r($respuestas);
    ?>
    <?php if(empty($respuestas)): ?>
    <p>No hay respuestas para mostrar</p>
    <a href="<?php echo e(url('/traslados')); ?>" class="btn btn-primary btn-lg mx-2">Traslados</a>
    <?php else: ?>
        <?php if(isset($respuestas['error'])): ?>
            <?php echo e($respuestas['error']); ?>

            <?php if(isset($respuestas['validation_errors'])): ?>
                <?php $__currentLoopData = $respuestas['validation_errors']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php $__currentLoopData = $error; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detelle_error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <p><?php echo e($detelle_error); ?></p>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
            <a href="<?php echo e(url('/traslados')); ?>" class="btn btn-primary btn-lg mx-2">Traslados</a>
        <?php else: ?>
            <!-- Tabla para mostrar los datos de las respuestas -->
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>Campo</th>
                        <th>Valor</th>
                        
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $respuestas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $respuesta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <!-- Fila 1: Nombre del Servicio -->
                        <tr class="<?php echo e(is_numeric($index) && $index % 2 == 0 ? 'bg-light' : 'bg-dark text-white'); ?>">
                            <td><strong>Nombre Servicio</strong></td>
                            <td><?php echo e($respuesta['Nombre_Servicio']); ?></td>
                        </tr>

                        <!-- Fila 2: Detalle del Servicio -->
                        <tr class="<?php echo e($index % 2 == 0 ? 'bg-light' : 'bg-dark text-white'); ?>">
                            <td><strong>Detalle del Servicio</strong></td>
                            <td colspan="2"><?php echo e($respuesta['Detalle_servicio']); ?></td>
                        </tr>

                        <!-- Fila 3: Formulario con campos y botón -->
                        <tr class="<?php echo e($index % 2 == 0 ? 'bg-light' : 'bg-dark text-white'); ?>">
                            <td><strong>Origen/Destino</strong></td>
                            <td colspan="2">
                                <form id="form-<?php echo e($index); ?>" action="<?php echo e(route('traslados.addCarrito')); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <!-- Campos ocultos -->
                                    <input type="hidden" name="Traslados_contrato_id" value="<?php echo e($respuesta['Traslados_contrato_id']); ?>">
                                    <input type="hidden" name="Tipo_movilidad_id" value="<?php echo e($respuesta['Tipo_movilidad_id']); ?>">
                                    <input type="hidden" name="Id_servicio_traslado" value="<?php echo e($respuesta['Id_servicio_traslado']); ?>">
                                    <input type="hidden" name="Fecha_disponible" value="<?php echo e($respuesta['Fecha_disponible']); ?>">
                                    <input type="hidden" name="Tipo_servicio" value="<?php echo e($respuesta['Tipo_servicio']); ?>">
                                    <input type="hidden" name="Tipo_servicio_transfer" value="<?php echo e($respuesta['Tipo_servicio_transfer']); ?>">
                                    <input type="hidden" name="hora_servicio" value="<?php echo e($respuesta['hora_servicio']); ?>">
                                    <input type="hidden" name="Numero_adultos" value="<?php echo e($respuesta['Cantidad_adultos']); ?>">
                                    <input type="hidden" name="Numero_menores" value="<?php echo e($respuesta['Cantidad_menores']); ?>">
                                    
                                    <?php if(isset($respuesta['Edad_menores'])): ?>
                                        <?php $__currentLoopData = $respuesta['Edad_menores']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $edad): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <input type="hidden" name="Edad_menores[<?php echo e($key); ?>]" value="<?php echo e($edad); ?>">
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>

                                    <!-- Campos visibles -->
                                    <div class="row g-2 mb-3">
                                        <div class="col-md-6">
                                            <input type="text" class="form-control <?php $__errorArgs = ['Lugar_Origen'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                                name="Lugar_Origen" placeholder="Ej: Aeropuerto Viru Viru (VVI)" 
                                                value="<?php echo e(old('Lugar_Origen')); ?>" required>
                                            <?php $__errorArgs = ['Lugar_Origen'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                        <div class="col-md-6">
                                            <input type="text" class="form-control <?php $__errorArgs = ['Lugar_Destino'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                                name="Lugar_Destino" placeholder="Ej: Hotel Camino Real" 
                                                value="<?php echo e(old('Lugar_Destino')); ?>" required>
                                            <?php $__errorArgs = ['Lugar_Destino'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>

                                    <!-- Botón de confirmación DENTRO del formulario -->
                                    <button type="submit" class="btn btn-success">
                                        <i class="fas fa-check-circle"></i> Confirmar Reserva
                                    </button>
                                </form>
                            </td>
                        </tr>

                        <!-- Fila 4: Precio Total -->
                        <tr class="<?php echo e($index % 2 == 0 ? 'bg-light' : 'bg-dark text-white'); ?>">
                            <td><strong>Precio Total</strong></td>
                            <td colspan="2"><?php echo e($respuesta['Precio_Total']); ?></td>
                        </tr>

                        <!-- Fila 5: Fecha Disponible -->
                        <tr class="<?php echo e($index % 2 == 0 ? 'bg-light' : 'bg-dark text-white'); ?>">
                            <td><strong>Fecha Disponible</strong></td>
                            <td colspan="2"><?php echo e($respuesta['Fecha_disponible']); ?></td>
                        </tr>

                        <!-- Fila 6: Hora de Servicio -->
                        <tr class="<?php echo e($index % 2 == 0 ? 'bg-light' : 'bg-dark text-white'); ?>">
                            <td><strong>Hora Servicio</strong></td>
                            <td colspan="2"><?php echo e($respuesta['hora_servicio']); ?></td>
                        </tr>

                        <!-- Fila 7: Foto del Vehículo -->
                        <tr class="<?php echo e($index % 2 == 0 ? 'bg-light' : 'bg-dark text-white'); ?>">
                            <td><strong>Vehículo</strong></td>
                            <td colspan="2">
                                <img src="<?php echo e($respuesta['Foto_tipo_movilidad']); ?>" alt="Vehículo" class="img-thumbnail" width="150">
                            </td>
                        </tr>

                        <!-- Fila 8: Pasajeros -->
                        <tr class="<?php echo e($index % 2 == 0 ? 'bg-light' : 'bg-dark text-white'); ?>">
                            <td><strong>Pasajeros</strong></td>
                            <td colspan="2">
                                <?php echo e($respuesta['Cantidad_adultos']); ?> Adultos / 
                                <?php echo e($respuesta['Cantidad_menores']); ?> Menores
                            </td>
                        </tr>

                        <!-- Fila 9: Edades de Menores (opcional) -->
                        <?php if(isset($respuesta['Edad_menores'])): ?>
                        <tr class="<?php echo e($index % 2 == 0 ? 'bg-light' : 'bg-dark text-white'); ?>">
                            <td><strong>Edades de Menores</strong></td>
                            <td colspan="2">
                                <?php $__currentLoopData = $respuesta['Edad_menores']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $edad): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    Menor <?php echo e($key); ?>: <?php echo e($edad); ?> años<br>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </td>
                        </tr>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        <?php endif; ?>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\travelamedida\resources\views/traslados/respuestas.blade.php ENDPATH**/ ?>