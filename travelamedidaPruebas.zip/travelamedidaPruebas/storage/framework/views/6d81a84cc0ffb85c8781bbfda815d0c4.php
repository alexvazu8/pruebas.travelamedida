<?php $__env->startSection('template_title'); ?>
    <?php echo e($reserva->name ?? __('Show') . " " . __('Reserva')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section class="content container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header" style="display: flex; justify-content: space-between; align-items: center;">
                        <div class="float-left">
                            <span class="card-title"><?php echo e(__('Show')); ?> Reserva</span>
                        </div>
                        <div class="float-right">
                            <a class="btn btn-primary btn-sm" href="<?php echo e(route('reservas.index')); ?>"> <?php echo e(__('Back')); ?></a>
                        </div>
                    </div>

                    <div class="card-body bg-white">
                        
                                <div class="form-group mb-2 mb20">
                                    <strong>Localizador:</strong>
                                    <?php echo e($reserva->Localizador); ?>

                                </div>
                                <div class="form-group mb-2 mb20">
                                    <strong>Importe Reserva:</strong>
                                    <?php echo e($reserva->Importe_Reserva); ?>

                                </div>
                                <div class="form-group mb-2 mb20">
                                    <strong>Nombre Cliente:</strong>
                                    <?php echo e($reserva->Nombre_Cliente); ?>

                                </div>
                                <div class="form-group mb-2 mb20">
                                    <strong>Email Contacto Reserva:</strong>
                                    <?php echo e($reserva->Email_contacto_reserva); ?>

                                </div>
                                <div class="form-group mb-2 mb20">
                                    <strong>Comentarios:</strong>
                                    <?php echo e($reserva->Comentarios); ?>

                                </div>
                                <div class="form-group mb-2 mb20">
                                    <strong>Usuario Id:</strong>
                                    <?php echo e($reserva->Usuario_id); ?>

                                </div>

                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\travelamedida\resources\views/reserva/show.blade.php ENDPATH**/ ?>