

<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>Respuestas del Traslado</h1>
    <?php 
    //print_r($respuestas);
    ?>
    <?php if(isset($respuestas['error'])): ?>
        <?php 
        print_r($respuestas);
        ?>
          <?php echo e($respuestas['error']); ?>

          <a href="<?php echo e(url('/traslados')); ?>" class="btn btn-primary btn-lg mx-2">Traslados</a>
    <?php else: ?>
        <?php if(empty($respuestas)): ?>
            <p>No hay respuestas disponibles.</p>
           
            <a href="<?php echo e(url('/traslados')); ?>" class="btn btn-primary btn-lg mx-2">Traslados</a>
        
        <?php else: ?>
           
       
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th>Campo</th>
                            <th>Valor</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>Hora de Servicio</td>
                            <td><?php echo e($respuestas['hora_servicio']); ?></td>
                        </tr>
                        <tr>
                            <td>Precio Adulto</td>
                            <td><?php echo e($respuestas['Precio_Adulto']); ?></td>
                        </tr>
                        <tr>
                            <td>Precio Menor</td>
                            <td><?php echo e($respuestas['Precio_Menor']); ?></td>
                        </tr>
                        <tr>
                            <td>Cantidad de Adultos</td>
                            <td><?php echo e($respuestas['Cantidad_Adultos']); ?></td>
                        </tr>
                        <tr>
                            <td>Cantidad de Menores</td>
                            <td><?php echo e($respuestas['Cantidad_Menores']); ?></td>
                        </tr>
                        <tr>
                            <td>Precio Total</td>
                            <td><?php echo e($respuestas['Precio_Total']); ?></td>
                        </tr>
                        <tr>
                            <td>Tipo de Movilidad</td>
                            <td><?php echo e($respuestas['Empresa_traslados_tipo_movilidades_id']); ?></td>
                        </tr>
                        <tr>
                            <td>Fecha de Servicio</td>
                            <td><?php echo e($respuestas['fecha_servicio']); ?></td>
                        </tr>
                        <tr>
                            <td>ID Carrito</td>
                            <td><?php echo e($respuestas['carrito_compras_items_id']); ?></td>
                        </tr>
                        <tr>
                            <td>Última Actualización</td>
                            <td><?php echo e($respuestas['updated_at']); ?></td>
                        </tr>
                        <tr>
                            <td>Creado en</td>
                            <td><?php echo e($respuestas['created_at']); ?></td>
                        </tr>
                        <tr>
                            <td>ID</td>
                            <td><?php echo e($respuestas['id']); ?></td>
                        </tr>
                    </tbody>
                </table>
                <a href="<?php echo e(url('/traslados')); ?>" class="btn btn-primary">Volver a Traslados</a>    
       
        <?php endif; ?>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\travelamedida\resources\views/traslados/respuestaCarrito.blade.php ENDPATH**/ ?>