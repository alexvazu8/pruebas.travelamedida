

<?php $__env->startSection('content'); ?>
<div class="container-fluid px-4">
    <h1 class="text-center mb-4 text-primary">Hoteles Disponibles</h1>

    
    <?php if(isset($respuestas['error'])): ?>
        <div class="alert alert-danger">
            <strong>Error:</strong> <?php echo e($respuestas['error']); ?>

            <a href="<?php echo e(url('/hoteles')); ?>" class="btn btn-primary btn-lg mx-2">Hoteles</a>
            <?php echo e(print_r(old(), true)); ?>

        </div>
    <?php elseif(count($respuestas['data']) > 0): ?>
        
        <?php $__currentLoopData = $respuestas['data']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hotel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <form method="POST" action="<?php echo e(route('hoteles.addCarrito')); ?>" class="mb-4">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="Tipo_servicio" value="H">
                <input type="hidden" name="Id_Hotel" value="<?php echo e($hotel['Id_Hotel']); ?>">
                <input type="hidden" name="Nombre_Hotel" value="<?php echo e($hotel['Nombre_Hotel']); ?>">
                <input type="hidden" name="Fecha_in" value="<?php echo e($hotel['Fecha_desde']); ?>">
                <input type="hidden" name="Fecha_out" value="<?php echo e($hotel['Fecha_hasta']); ?>">

                
                <div class="card shadow-sm border-0 mb-3">
                    <div class="card-header bg-primary text-white">
                        <div class="d-flex justify-content-between align-items-center">
                            <h5 class="mb-0">
                                <?php echo e($hotel['Nombre_Hotel']); ?>

                                <a href="#" data-bs-toggle="modal" data-bs-target="#hotelModal<?php echo e($hotel['Id_Hotel']); ?>" class="text-white ms-2">Info</a>
                            </h5>
                            <span class="text-warning"><?php echo e(str_repeat('⭐', $hotel['estrellas_id'])); ?></span>
                        </div>
                    </div>

                    <div class="card-body">
                        <div class="row align-items-start">
                            
                            <div class="col-md-4 text-center">
                                <img src="<?php echo e($hotel['Foto_Principal_Hotel']); ?>" alt="Foto de <?php echo e($hotel['Nombre_Hotel']); ?>" class="img-fluid rounded" style="max-height: 200px; object-fit: cover;">
                                <p class="mb-1"><strong>Dirección:</strong> <?php echo e($hotel['Direccion_Hotel']); ?></p>
                            </div>

                            
                            <div class="col-md-8">
                                <p><strong>Fecha In:</strong> <?php echo e($hotel['Fecha_desde']); ?> <strong>Fecha Out:</strong> <?php echo e($hotel['Fecha_hasta']); ?></p>

                                
                                <?php if(isset($hotel['habitaciones']) && count($hotel['habitaciones']) > 0): ?>
                                    <div class="mt-1">
                                        <?php $__currentLoopData = $hotel['habitaciones']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $grupoHabitaciones): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="me-1 mb-0" style="flex: 1 1 200px;">
                                                
                                                <button type="button" class="btn btn-light w-100 text-start mb-2" data-bs-toggle="collapse" data-bs-target="#collapseHabitacion<?php echo e($index); ?>" aria-expanded="false" aria-controls="collapseHabitacion<?php echo e($index); ?>">
                                                    <span class="fw-bold">Monto Total: $<span id="totalMonto<?php echo e($index); ?>"><?php echo e(number_format($grupoHabitaciones[0]['Total'], 2)); ?></span></span>
                                                    / Habitaciones: <?php echo e($grupoHabitaciones[0]['Cantidad_habitaciones']); ?> 
                                                    / Noches: <?php echo e($grupoHabitaciones[0]['Cantidad_Noches']); ?>

                                                    / <?php echo e($grupoHabitaciones[0]['Cantidad_Adultos']); ?> adultos, <?php echo e($grupoHabitaciones[0]['Cantidad_Menores']); ?> menores
                                                    / Detalle...
                                                </button>

                                                
                                                <div class="collapse" id="collapseHabitacion<?php echo e($index); ?>">
                                                    <div class="d-flex flex-column">
                                                        <?php $__currentLoopData = $grupoHabitaciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $habitacion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <div class="form-check p-2 mb-1 border rounded bg-light">
                                                                <input 
                                                                    type="radio" 
                                                                    name="habitaciones[<?php echo e($index); ?>]" 
                                                                    id="habitacion_<?php echo e($habitacion['Id_tipo_habitacion_hotels']); ?>" 
                                                                    class="form-check-input" 
                                                                    value="<?php echo e(json_encode($habitacion)); ?>" 
                                                                    <?php echo e($loop->first ? 'checked' : ''); ?>

                                                                    data-total="<?php echo e($habitacion['Total']); ?>" 
                                                                    required>
                                                                <label for="habitacion_<?php echo e($habitacion['Id_tipo_habitacion_hotels']); ?>" class="form-check-label">
                                                                    <strong><?php echo e($habitacion['Nombre_Habitacion']); ?> <?php echo e($habitacion['Nombre_Regimen']); ?></strong><br>
                                                                    <?php echo e($habitacion['Cantidad_habitaciones']); ?> habitaciones<br>
                                                                    <?php echo e($habitacion['Cantidad_Adultos']); ?> adultos, <?php echo e($habitacion['Cantidad_Menores']); ?> menores<br>
                                                                    <?php echo e($habitacion['Cantidad_Noches']); ?> noches<br>
                                                                    <span class="text-success">$<?php echo e(number_format($habitacion['Total'], 2)); ?> total</span>
                                                                </label>
                                                            </div>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </div>
                                                </div>
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                        
                                        <div class="card-footer text-end bg-light d-flex justify-content-between align-items-center">
                                            <h5 class="mb-0 me-3"><strong>Total:</strong> $<span id="totalAcumulado">0.00</span></h5>
                                            <button type="submit" class="btn btn-primary px-4">Enviar al Carrito</button>
                                        </div>
                                    </div>
                                <?php else: ?>
                                    <div class="alert alert-info mt-3">
                                        No hay habitaciones disponibles en este hotel.
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </form>

            
            <div class="modal fade" id="hotelModal<?php echo e($hotel['Id_Hotel']); ?>" tabindex="-1" aria-labelledby="hotelModalLabel" aria-hidden="true">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title">Información del Hotel</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body" id="hotel-info-<?php echo e($hotel['Id_Hotel']); ?>"></div>
                        <div id="hotel-map" style="width: 100%;"></div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cerrar</button>
                        </div>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php else: ?>
        <div class="alert alert-info">
            No se encontraron hoteles disponibles.
        </div>
    <?php endif; ?>
</div>


<script>
    document.addEventListener('DOMContentLoaded', function() {
        const actualizarTotalAcumulado = () => {
            let totalAcumulado = 0;
            document.querySelectorAll('input[type="radio"]:checked').forEach(radio => {
                totalAcumulado += parseFloat(radio.getAttribute('data-total'));
            });
            document.getElementById('totalAcumulado').innerText = totalAcumulado.toFixed(2);
        };

        document.querySelectorAll('input[type="radio"]').forEach(radio => {
            radio.addEventListener('change', (e) => {
                const grupoIndex = e.target.name.match(/\d+/)[0];
                document.getElementById('totalMonto' + grupoIndex).innerText = parseFloat(e.target.getAttribute('data-total')).toFixed(2);
                actualizarTotalAcumulado();
            });
        });

        actualizarTotalAcumulado();

        // Evento para manejar el clic en el enlace "Info"
        document.querySelectorAll('a[data-bs-toggle="modal"]').forEach(function(link) {
            link.addEventListener('click', function(event) {
                // Obtener el ID del hotel desde el enlace
                const hotelId = this.getAttribute('data-bs-target').replace('#hotelModal', '');

                // Hacer una solicitud AJAX para obtener más información del hotel
                fetch(`/hoteles/info/${hotelId}`)
                    .then(response => response.json())
                    .then(data => {
                        if (data.success) {
                            const hotel = data.hotel;
                            const modalBody = document.getElementById(`hotel-info-${hotelId}`);
                            
                            // Construir el contenido ordenado
                            let modalContent = `
                                <h5>${hotel.Nombre_Hotel} ${'⭐'.repeat(hotel.estrellas.estrellas)}</h5>
                                 <p>${hotel.ciudad.Nombre_Ciudad}, ${hotel.pais.Nombre_Pais}</p>
                                <p><strong>Dirección:</strong> ${hotel.Direccion_Hotel}</p>
                                <p><strong>Descripción:</strong> ${hotel.Descripcion_Hotel}</p>

                                <h5>Fotos del Hotel</h5>
                                <div class="gallery">
                                    <img src="${hotel.Foto_Principal_Hotel}" alt="Foto principal de ${hotel.Nombre_Hotel}" class="img-fluid mb-3" style="max-height: 300px; object-fit: cover;">
                                    ${hotel.fotos_hotels.map(foto => `
                                        <img src="${foto.Foto_Hotel}" alt="Foto adicional de ${hotel.Nombre_Hotel}" class="img-fluid mb-3" style="max-height: 200px; object-fit: cover;">
                                    `).join('')}
                                </div>

                                <p><strong>Latitud:</strong> ${hotel.Latitud} <br> <strong>Longitud:</strong> ${hotel.Longitud}</p>

                                <div id="hotel-map" style="height: 400px; width: 100%;"></div>

                                <h5>Facilidades y Servicios</h5>
                                <ul>
                                    ${hotel.hotel_facilidades_y_servicios.map(servicio => `
                                        <li>${servicio.texto_facilidad} - ${servicio.costo} ${servicio.moneda}</li>
                                    `).join('')}
                                </ul>

                                <h5>Tipos de Habitaciones</h5>
                                <ul>
                                    ${hotel.tipo_habitacion_hotels.map(habitacion => `
                                        <li><strong>${habitacion.Nombre_Habitacion}</strong>
                                            <p>Edad Menores Gratis: ${habitacion.Edad_menores_gratis} años</p>
                                        </li>
                                    `).join('')}
                                </ul>
                            `;

                            // Asignar el contenido al cuerpo del modal
                            modalBody.innerHTML = modalContent;

                            // Inicializar el mapa de OpenStreetMap
                            const map = L.map('hotel-map').setView([hotel.Latitud, hotel.Longitud], 13); // Coordenadas del hotel

                            // Añadir la capa del mapa
                            L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
                                attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
                            }).addTo(map);

                            // Añadir un marcador en la ubicación del hotel
                            L.marker([hotel.Latitud, hotel.Longitud]).addTo(map)
                                .bindPopup(`<b>${hotel.Nombre_Hotel}</b><br>${hotel.Direccion_Hotel}`)
                                .openPopup();
                        } else {
                            // En caso de error, mostrar un mensaje en el modal
                            const modalBody = document.getElementById(`hotel-info-${hotelId}`);
                            modalBody.innerHTML = `<p class="text-danger">${data.message}</p>`;
                        }
                    })
                    .catch(error => {
                        console.error('Error al cargar la información del hotel:', error);
                        const modalBody = document.getElementById(`hotel-info-${hotelId}`);
                        modalBody.innerHTML = `<p class="text-danger">Hubo un error al intentar obtener la información del hotel.</p>`;
                    });
            });
        });
    });
</script>

<!-- Incluir CSS de Leaflet -->
<link rel="stylesheet" href="https://unpkg.com/leaflet/dist/leaflet.css"/>

<!-- Incluir JavaScript de Leaflet -->
<script src="https://unpkg.com/leaflet/dist/leaflet.js"></script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\travelamedida\resources\views/hoteles/respuestas.blade.php ENDPATH**/ ?>