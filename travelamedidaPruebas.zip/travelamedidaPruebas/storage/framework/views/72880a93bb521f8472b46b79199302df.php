

<?php $__env->startSection('content'); ?>
<div class="container">
    <h1 class="text-xl font-bold mb-4">Detalles del Carrito</h1>

    
    <?php if(isset($mensaje)): ?>
        <div class="alert <?php echo e($mensaje === 'Exito!!!' ? 'alert-success' : 'alert-danger'); ?>">
            <?php echo e($mensaje); ?>

        </div>
    <?php endif; ?>

    
    <?php if(isset($respuestas) && is_array($respuestas)): ?>
        <!-- Muesta el contador de en cuanto exprira el carrito-->
        <div id="countdown"></div>

        
        <?php if(isset($respuestas['Precio_total_carrito'])): ?>
            <?php
            $exp=$respuestas[0]['expiration_token'];
            ?>
            <script>
                // Timestamp de expiración (pasado desde Laravel)
                const expTimestamp = <?php echo e($exp); ?>;

                function updateCountdown() {
                    const now = Math.floor(Date.now() / 1000); // Timestamp actual en segundos
                    const remainingTime = expTimestamp - now;

                    if (remainingTime <= 0) {
                        document.getElementById('countdown').innerHTML = "Token expirado";
                        return;
                    }

                    // Convertir segundos a horas, minutos y segundos
                    const hours = Math.floor(remainingTime / 3600);
                    const minutes = Math.floor((remainingTime % 3600) / 60);
                    const seconds = remainingTime % 60;

                    document.getElementById('countdown').innerHTML = 
                        `Tiempo restante: ${hours}h ${minutes}m ${seconds}s`;

                    // Actualizar cada segundo
                    setTimeout(updateCountdown, 1000);
                }

                // Iniciar el contador
                updateCountdown();
            </script>
            <div class="alert alert-info">
                <strong>Precio Total del Carrito:</strong> <?php echo e(number_format($respuestas['Precio_total_carrito'], 2)); ?>

            </div>
            
            <div class="container">
                <form action="<?php echo e(route('carritos.borrar')); ?>" method="POST" onsubmit="return confirm('¿Estás seguro de que deseas eliminar este carrito?');">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit" class="btn btn-danger">Vaciar Carrito</button>
                </form>
            </div>
            
            <div class="container">
                <form action="<?php echo e(route('reservas.confirmar')); ?>" method="POST" class="mb-4">
                    <?php echo csrf_field(); ?>
                    <div class="row mb-3">
                        <div class="row md-6">
                            <label for="Nombre_titular_reserva">Nombre del Titular de la Reserva</label>
                            <input type="text" name="Nombre_titular_reserva" id="Nombre_titular_reserva" class="form-control rounded-pill px-4"  maxlength="20"  pattern="[A-Za-z\s]+" oninput="this.value = this.value.replace(/[^A-Za-z\s]/g, '')" required>
                        </div>
                        <div class="row md-6">
                            <label for="Apellido_titular_reserva">Apellido del Titular de la Reserva</label>
                            <input type="text" name="Apellido_titular_reserva" id="Apellido_titular_reserva" class="form-control rounded-pill px-4"  maxlength="20" pattern="[A-Za-z\s]+" oninput="this.value = this.value.replace(/[^A-Za-z\s]/g, '')" required>
                        </div>
                        <div class="row md-6">
                            <label for="Telefono_titular_reserva">Telefono del Titular de la Reserva</label>
                            <input type="text" name="Telefono_titular_reserva" id="Telefono_titular_reserva" class="form-control rounded-pill px-4" pattern="^[+\-\d\s]+$" required>
                        </div>
                        <div class="row mb-3">
                            <label for="Email_contacto_reserva">Email de Contacto</label>
                            <input type="email" name="Email_contacto_reserva" id="Email_contacto_reserva" class="form-control rounded-pill px-4">
                        </div>
                        <div class="row mb-4">
                            <label for="Comentarios" class="col-md-6">Comentarios (Opcional)</label>
                            <textarea name="Comentarios" id="Comentarios" class="form-control rounded-pill px-4 py-2" rows="3"></textarea>
                        </div>
                        <button type="submit" class="btn btn-primary px-4">Reservar</button>
                    </div>
                </form>
            </div>
        <?php endif; ?>

        
        <?php $__currentLoopData = $respuestas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $carrito): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if(is_array($carrito)): ?> 
                <div class="card mb-4">
                    <div class="card-header font-bold">Servicio #<?php echo e($carrito['id'] ?? 'N/A'); ?></div>
                    <div class="card-body">
                        
                        <p><strong>Tipo de Servicio:</strong> 
                            <?php if(isset($carrito['Tipo_servicio'])): ?>
                                <?php if($carrito['Tipo_servicio'] === 'T'): ?>
                                    Traslado
                                <?php elseif($carrito['Tipo_servicio'] === 'TOU'): ?>
                                    Tour
                                <?php elseif($carrito['Tipo_servicio'] === 'H'): ?>
                                    Hotel
                                <?php else: ?>
                                    <?php echo e($carrito['Tipo_servicio']); ?>

                                <?php endif; ?>
                            <?php else: ?>
                                N/A
                            <?php endif; ?>
                        </p>
                        <p><strong>Precio Total:</strong> <?php echo e(isset($carrito['Precio_Total']) ? number_format($carrito['Precio_Total'], 2) : 'N/A'); ?></p>
                        <p><strong>Fecha de Creación:</strong> <?php echo e(isset($carrito['created_at']) ? \Carbon\Carbon::parse($carrito['created_at'])->translatedFormat('d F Y') : 'N/A'); ?></p>
                        <p><strong>Fecha de Actualización:</strong> <?php echo e(isset($carrito['updated_at']) ? \Carbon\Carbon::parse($carrito['updated_at'])->translatedFormat('d F Y') : 'N/A'); ?></p>
                        
                        <?php if(isset($carrito['Email_encargado_reserva'])): ?>
                            <p><strong>Email del Encargado de Reserva:</strong> <?php echo e($carrito['Email_encargado_reserva']); ?></p>
                        <?php endif; ?>
                    </div>

                    
                    <div class="card mt-3">
                        <div class="card-header font-bold">Detalle del Servicio</div>
                        <div class="card-body">
                            <?php if(isset($carrito['detalle']) && is_array($carrito['detalle'])): ?>
                                <?php if($carrito['Tipo_servicio'] === 'H'): ?>
                                    
                                    <table class="table table-striped">
                                        <thead>
                                            <tr>
                                                <th>Fecha de Entrada</th>
                                                <th>Fecha de Salida</th>
                                                <th>Tipo de Habitación</th>
                                                <th>Régimen</th>
                                                <th>Cant. Adultos</th>
                                                <th>Cant. Menores</th>
                                                <th>Cant. Noches</th>
                                                <th>Precio Promedio por Noche</th>
                                                <th>Precio Total</th>
                                                <th>Cant. Habitaciones</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $carrito['detalle']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detalle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td><?php echo e(isset($detalle['Fecha_In']) ? \Carbon\Carbon::parse($detalle['Fecha_In'])->translatedFormat('d F Y') : 'N/A'); ?></td>
                                                    <td><?php echo e(isset($detalle['Fecha_Out']) ? \Carbon\Carbon::parse($detalle['Fecha_Out'])->translatedFormat('d F Y') : 'N/A'); ?></td>
                                                    <td><?php echo e($detalle['Nombre_Habitacion'] ?? 'N/A'); ?></td>
                                                    <td><?php echo e($detalle['Nombre_Regimen'] ?? 'N/A'); ?></td>
                                                    <td><?php echo e($detalle['Cantidad_Adultos'] ?? 'N/A'); ?></td>
                                                    <td><?php echo e($detalle['Cantidad_Menores'] ?? 'N/A'); ?></td>
                                                    <td><?php echo e($detalle['Cantidad_Noches'] ?? 'N/A'); ?></td>
                                                    <td><?php echo e(isset($detalle['Precio_promedio_por_noche']) ? number_format($detalle['Precio_promedio_por_noche'], 2) : 'N/A'); ?></td>
                                                    <td><?php echo e(isset($detalle['Precio_total_habitacion']) ? number_format($detalle['Precio_total_habitacion'], 2) : 'N/A'); ?></td>
                                                    <td><?php echo e($detalle['Cantidad_habitaciones'] ?? 'N/A'); ?></td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                <?php elseif($carrito['Tipo_servicio'] === 'T'): ?>
                                    
                                    <table class="table table-striped">
                                        <thead>
                                            <tr>
                                                <th>Fecha del Servicio</th>
                                                <th>Hora del Servicio</th>
                                                <th>Cant. Adultos</th>
                                                <th>Cant. Menores</th>
                                                <th>Precio Adulto</th>
                                                <th>Precio Menor</th>
                                                <th>Precio Total</th>
                                                <th>Marca/Modelo</th>
                                                <th>Maletas Máximo</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $carrito['detalle']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detalle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td><?php echo e(isset($detalle['fecha_servicio']) ? \Carbon\Carbon::parse($detalle['fecha_servicio'])->translatedFormat('d F Y') : 'N/A'); ?></td>
                                                    <td><?php echo e($detalle['hora_servicio'] ?? 'N/A'); ?></td>
                                                    <td><?php echo e($detalle['Cantidad_Adultos'] ?? 'N/A'); ?></td>
                                                    <td><?php echo e($detalle['Cantidad_Menores'] ?? 'N/A'); ?></td>
                                                    <td><?php echo e(isset($detalle['Precio_Adulto']) ? number_format($detalle['Precio_Adulto'], 2) : 'N/A'); ?></td>
                                                    <td><?php echo e(isset($detalle['Precio_Menor']) ? number_format($detalle['Precio_Menor'], 2) : 'N/A'); ?></td>
                                                    <td><?php echo e(isset($detalle['Precio_Total']) ? number_format($detalle['Precio_Total'], 2) : 'N/A'); ?></td>
                                                    <td><?php echo e(isset($detalle['empresa_traslado_tipo_movilidade']['Marca_modelo']) ? $detalle['empresa_traslado_tipo_movilidade']['Marca_modelo'] : 'N/A'); ?></td>
                                                    <td><?php echo e(isset($detalle['empresa_traslado_tipo_movilidade']['Maletas_maximo']) ? $detalle['empresa_traslado_tipo_movilidade']['Maletas_maximo'] : 'N/A'); ?></td>
                                                </tr>
                                                
                                                <?php if(isset($detalle['servicio_traslado'])): ?>
                                                    <tr>
                                                        <td colspan="9">
                                                            <strong>Servicio:</strong> <?php echo e($detalle['servicio_traslado']['Nombre_Servicio'] ?? 'N/A'); ?> <br>
                                                            <strong>Detalle:</strong> <?php echo e($detalle['servicio_traslado']['Detalle_servicio'] ?? 'N/A'); ?> <br>
                                                            <strong>Tipo:</strong> <?php echo e($detalle['servicio_traslado']['Tipo_servicio_transfer'] ?? 'N/A'); ?>

                                                        </td>
                                                    </tr>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                <?php elseif($carrito['Tipo_servicio'] === 'TOU'): ?>
                                    
                                    <table class="table table-striped">
                                        <thead>
                                            <tr>
                                                <th>Nombre del Tour</th>
                                                <th>Fecha de Inicio</th>
                                                <th>Fecha de Fin</th>
                                                <th>Cant. Adultos</th>
                                                <th>Cant. Menores</th>
                                                <th>Precio Adulto</th>
                                                <th>Precio Menor</th>
                                                <th>Precio Total</th>
                                                <th>Duración</th>
                                                <th>Recojo en Hotel</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $carrito['detalle']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detalle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td><?php echo e($detalle['tour']['Nombre_tour'] ?? 'N/A'); ?></td>
                                                    <td><?php echo e(isset($detalle['Fecha_In']) ? \Carbon\Carbon::parse($detalle['Fecha_In'])->translatedFormat('d F Y') : 'N/A'); ?></td>
                                                    <td><?php echo e(isset($detalle['Fecha_Out']) ? \Carbon\Carbon::parse($detalle['Fecha_Out'])->translatedFormat('d F Y') : 'N/A'); ?></td>
                                                    <td><?php echo e($detalle['Cantidad_Adultos'] ?? 'N/A'); ?></td>
                                                    <td><?php echo e($detalle['Cantidad_Menores'] ?? 'N/A'); ?></td>
                                                    <td><?php echo e(isset($detalle['Precio_Adulto']) ? number_format($detalle['Precio_Adulto'], 2) : 'N/A'); ?></td>
                                                    <td><?php echo e(isset($detalle['Precio_Menor']) ? number_format($detalle['Precio_Menor'], 2) : 'N/A'); ?></td>
                                                    <td><?php echo e(isset($detalle['Precio_Total']) ? number_format($detalle['Precio_Total'], 2) : 'N/A'); ?></td>
                                                    <td><?php echo e($detalle['tour']['cantidad_dias_tour'] ?? 'N/A'); ?> días / <?php echo e($detalle['tour']['cantidad_noches_tour'] ?? 'N/A'); ?> noches</td>
                                                    <td><?php echo e($detalle['tour']['Recojo_hotel'] == 1 ? 'Sí' : 'No'); ?></td>
                                                </tr>
                                                
                                                <?php if(isset($detalle['tour'])): ?>
                                                    <tr>
                                                        <td colspan="10">
                                                            <strong>País:</strong> <?php echo e($detalle['tour']['pais']['Nombre_Pais'] ?? 'N/A'); ?> <br>
                                                            <strong>Ciudad:</strong> <?php echo e($detalle['tour']['ciudad']['Nombre_Ciudad'] ?? 'N/A'); ?> <br>
                                                            <strong>Zona:</strong> <?php echo e($detalle['tour']['zona']['Nombre_Zona'] ?? 'N/A'); ?>

                                                        </td>
                                                    </tr>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                <?php endif; ?>
                            <?php else: ?>
                                <p>No hay detalles disponibles para este carrito.</p>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php else: ?>
        <p>No se encontraron datos para mostrar.</p>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\travelamedida\resources\views/carritos/show.blade.php ENDPATH**/ ?>