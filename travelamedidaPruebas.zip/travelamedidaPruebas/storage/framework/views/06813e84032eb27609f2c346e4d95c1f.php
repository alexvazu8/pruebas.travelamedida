

<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>Respuestas de disponibilidad Tours</h1>
    <?php if(isset($respuestas['error'])): ?>
    <?php 
    print_r($respuestas);
    ?>
          <?php echo e($respuestas['error']); ?>

          <a href="<?php echo e(url('/tours')); ?>" class="btn btn-primary btn-lg mx-2">Tours</a>
    <?php else: ?>
        Hay un Error
        <a href="<?php echo e(url('/tours')); ?>" class="btn btn-primary btn-lg mx-2">Tours</a>
        
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\travelamedida\resources\views/tours/errorCarrito.blade.php ENDPATH**/ ?>