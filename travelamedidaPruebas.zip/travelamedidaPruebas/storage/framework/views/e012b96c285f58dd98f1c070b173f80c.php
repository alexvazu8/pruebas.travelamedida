

<?php $__env->startSection('content'); ?>

    <div class="container">
        <h1>Disponibilidad de Traslados</h1>

        <!-- Formulario para obtener la disponibilidad -->
        <form action="<?php echo e(route('traslados.obtener')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label for="Fecha_disponible">Fecha de Disponibilidad</label>
                <input type="date"  id="Fecha_disponible" name="Fecha_disponible" class="form-control  bg-light text-dark"  value="<?php echo e(old('Fecha_disponible')); ?>" min="<?php echo e(now()->addDay()->format('Y-m-d')); ?>" required>
                <?php $__errorArgs = ['Fecha_disponible'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-danger"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="form-group">
                <label for="Tipo_servicio_transfer">IN/OUT/Hotel a Hotel</label>
                <select name="Tipo_servicio_transfer" id="Tipo_servicio_transfer" class="form-control" required>
                    <option value="IN" <?php echo e(old('Tipo_servicio_transfer') == 'IN' ? 'selected' : ''); ?>>Ingreso</option>
                    <option value="OUT" <?php echo e(old('Tipo_servicio_transfer') == 'OUT' ? 'selected' : ''); ?>>Salida</option>
                    <option value="HTH" <?php echo e(old('Tipo_servicio_transfer') == 'HTH' ? 'selected' : ''); ?>>De Hotel a Hotel</option>
                </select>
                <?php $__errorArgs = ['Tipo_servicio_transfer'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-danger"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="form-group">
                <label for="Pais_Id_Pais">Pais</label>
                <select name="Pais_Id_Pais" id="Pais_Id_Pais" class="form-control" required>
                <?php $__currentLoopData = $paises; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $paise): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>    
                <option value="<?php echo e($paise->Id_Pais); ?>" <?php if(old('Pais_Id_Pais') == $paise->Id_Pais): ?> selected <?php endif; ?>><?php echo e($paise->Nombre_Pais); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                </select>
                <?php $__errorArgs = ['Ciudad_Id_Ciudad'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-danger"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="form-group">
                <label for="Ciudad_Id_Ciudad">Ciudad</label>
                <select name="Ciudad_Id_Ciudad" id="Ciudad_Id_Ciudad" class="form-control" required>
                <option value="">Selecciona una ciudad</option>
                <?php $__currentLoopData = $ciudades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ciudad): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($ciudad->id_ciudad); ?>"  <?php if(old('Ciudad_Id_Ciudad') == $ciudad->id_ciudad): ?> selected <?php endif; ?>><?php echo e($ciudad->nombre_ciudad); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
                </select>
                <?php $__errorArgs = ['Ciudad_Id_Ciudad'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-danger"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <!-- Zona Origen -->
            <div class="form-group">
                <label for="Zona_Origen_id">Zona de Origen</label>
                <select name="Zona_Origen_id" id="Zona_Origen_id" class="form-control" required>
                    <option value="">Selecciona una zona</option>
                </select>
                <?php $__errorArgs = ['Zona_Origen_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-danger"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="form-group">
                <label for="Zona_Destino_id">Zona de Destino</label>
                <select name="Zona_Destino_id" id="Zona_Destino_id" class="form-control" required>
                    <option value="">Selecciona una zona destino</option>
                </select>
                <?php $__errorArgs = ['Zona_Destino_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-danger"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="form-group">
                <label for="hora_servicio">Hora de Servicio</label>
                <input type="time" id="hora_servicio" name="hora_servicio" class="form-control" value="<?php echo e(old('hora_servicio')); ?>" required>
                <?php $__errorArgs = ['hora_servicio'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-danger"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="form-group">
                <label for="Cantidad_adultos">Cantidad de Adultos</label>
                <input type="number" id="Cantidad_adultos" name="Cantidad_adultos" class="form-control" value="<?php echo e(old('Cantidad_adultos')); ?>" min="0" max="9" required  oninput="this.value = Math.min(9, this.value)">
                <?php $__errorArgs = ['Cantidad_adultos'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-danger"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="form-group">
                <label for="Cantidad_menores">Cantidad de Menores</label>
                <input type="number" id="Cantidad_menores" name="Cantidad_menores" class="form-control" min="0" max="5"  required  oninput="this.value = Math.min(5, this.value)">
                <?php $__errorArgs = ['Cantidad_menores'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-danger"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>           

            <div id="edadMenoresContainer" class="form-group" style="display: none;">
                <label for="Edad_menores">Edad de los Menores</label>
                <div id="edadMenoresInputs"></div>

            </div>

            <button type="submit" class="btn btn-primary">Obtener Disponibilidad</button>
        </form>
    </div>
      
   <script>
    document.addEventListener('DOMContentLoaded', function() {
        const cantidadMenoresInput = document.getElementById('Cantidad_menores');
        const edadMenoresContainer = document.getElementById('edadMenoresContainer');
        const edadMenoresInputs = document.getElementById('edadMenoresInputs');

        // Actualiza los campos de edad según la cantidad de menores
        cantidadMenoresInput.addEventListener('input', function() {
            const cantidadMenores = parseInt(cantidadMenoresInput.value);

            // Limpia los campos anteriores
            edadMenoresInputs.innerHTML = '';

            // Si hay menores, muestra los campos para ingresar las edades
            if (cantidadMenores > 0) {
                edadMenoresContainer.style.display = 'block';

                // Agrega los campos de edad para cada menor
                for (let i = 1; i <= cantidadMenores; i++) {
                    const label = document.createElement('label');
                    label.setAttribute('for', `Edad_menor_${i}`);
                    label.textContent = `Edad del menor ${i}`;

                    const input = document.createElement('input');
                    input.type = 'number';
                    input.id = `Edad_menor_${i}`;
                    input.name = `Edad_menores[${i}]`;
                    input.classList.add('form-control');
                    input.placeholder = `Edad del menor ${i}`;

                    // Crea el contenedor para el error
                    const errorContainer = document.createElement('div');
                    errorContainer.id = `error_Edad_menor_${i}`;
                    errorContainer.classList.add('text-danger');
                    
                    // Agrega el label, input y contenedor de error al contenedor
                    edadMenoresInputs.appendChild(label);
                    edadMenoresInputs.appendChild(input);
                    edadMenoresInputs.appendChild(errorContainer);  // Contenedor de error
                }
            } else {
                edadMenoresContainer.style.display = 'none';
            }
        });
    });


    document.addEventListener('DOMContentLoaded', function() {
            const ciudadSelect = document.getElementById('Ciudad_Id_Ciudad');
            const zonaOrigenSelect = document.getElementById('Zona_Origen_id');
            const zonaDestinoSelect = document.getElementById('Zona_Destino_id');
            const tipoServicioSelect = document.getElementById('Tipo_servicio_transfer'); // Campo para seleccionar el tipo de servicio
            
            // Evento para manejar el cambio de tipo de servicio
            tipoServicioSelect.addEventListener('change', function() {
                const ciudadId = this.value;
                
                const tipoServicio = tipoServicioSelect.value;  // Obtener el tipo de servicio seleccionado
               
                // Si no se seleccionó una ciudad, limpiamos las zonas
                if (!ciudadId) {
                    zonaOrigenSelect.innerHTML = '<option value="">Selecciona una zona</option>';
                    zonaDestinoSelect.innerHTML = '<option value="">Selecciona una zona</option>';
                    return;
                }

                // Realizar la petición AJAX para obtener las zonas de la ciudad seleccionada
                fetch(`/traslados/zonas-origen/${ciudadId}/${tipoServicio}`)
                    .then(response => response.json())
                    .then(data => { 
                        // Limpiar las opciones de las zonas
                        zonaOrigenSelect.innerHTML = '<option value="">Selecciona una zona</option>';
                        zonaDestinoSelect.innerHTML = '<option value="">Selecciona una zona</option>';

                        // Añadir las zonas de origen al select
                        data.zonas.forEach(zona => {
                            const option = document.createElement('option');
                            option.value = zona.Id_Zona;
                            option.textContent = `Zona ${zona.nombre_zona}`;
                            zonaOrigenSelect.appendChild(option);
                        });
                    })
                    .catch(error => {
                        console.error('Error al cargar las zonas:', error);
                    });
            });

            // Evento para manejar el cambio en la ciudad
            ciudadSelect.addEventListener('change', function() {
                const ciudadId = this.value;
                
                const tipoServicio = tipoServicioSelect.value;  // Obtener el tipo de servicio seleccionado
               
                // Si no se seleccionó una ciudad, limpiamos las zonas
                if (!ciudadId) {
                    zonaOrigenSelect.innerHTML = '<option value="">Selecciona una zona</option>';
                    zonaDestinoSelect.innerHTML = '<option value="">Selecciona una zona</option>';
                    return;
                }

                // Realizar la petición AJAX para obtener las zonas de la ciudad seleccionada
                fetch(`/traslados/zonas-origen/${ciudadId}/${tipoServicio}`)
                    .then(response => response.json())
                    .then(data => { 
                        // Limpiar las opciones de las zonas
                        zonaOrigenSelect.innerHTML = '<option value="">Selecciona una zona</option>';
                        zonaDestinoSelect.innerHTML = '<option value="">Selecciona una zona</option>';

                        // Añadir las zonas de origen al select
                        data.zonas.forEach(zona => {
                            const option = document.createElement('option');
                            option.value = zona.Id_Zona;
                            option.textContent = `Zona ${zona.nombre_zona}`;
                            zonaOrigenSelect.appendChild(option);
                        });
                    })
                    .catch(error => {
                        console.error('Error al cargar las zonas:', error);
                    });
            });

            // Evento para manejar el cambio en la zona de origen
            zonaOrigenSelect.addEventListener('change', function() {
                const zonaId = this.value;
                

                // Si no se seleccionó una zona de origen, limpiamos la zona de destino
                if (!zonaId) {
                    zonaDestinoSelect.innerHTML = '<option value="">Selecciona una zona</option>';
                    return;
                }
                
                // Realizar la petición AJAX para obtener las zonas de destino asociadas a la zona de origen seleccionada
                fetch(`/traslados/zonas-destino/${zonaId}`)
                    .then(response => response.json())
                    .then(data => {
                        // Limpiar las opciones de las zonas de destino
                        zonaDestinoSelect.innerHTML = '<option value="">Selecciona una zona</option>';

                        // Añadir las zonas de destino al select
                        data.zonas.forEach(zona => {
                            const option = document.createElement('option');
                            option.value = zona.Id_Zona;
                            option.textContent = `Zona ${zona.nombre_zona}`;
                            zonaDestinoSelect.appendChild(option);
                        });
                    })
                    .catch(error => {
                        console.error('Error al cargar las zonas de destino:', error);
                    });
            });
            // Inicializar Bootstrap Datepicker
            $('#Fecha_disponible').datepicker({
                format: 'dd/mm/yyyy', // Formato de fecha
                startDate: 'today',   // No permitir fechas pasadas
                autoclose: true,      // Cerrar automáticamente después de seleccionar
                todayHighlight: true, // Resaltar la fecha actual
                language: 'es',       // Traducir al español
                templates: {
                    leftArrow: '<i class="fas fa-chevron-left text-primary"></i>',
                    rightArrow: '<i class="fas fa-chevron-right text-primary"></i>'
                }
            });
           
           
    });
</script>


<?php $__currentLoopData = range(1, old('Cantidad_menores', 0)); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php $__errorArgs = ["Edad_menores.$i"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <span class="text-danger"><?php echo e($message); ?></span>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\travelamedida\resources\views/traslados/index.blade.php ENDPATH**/ ?>