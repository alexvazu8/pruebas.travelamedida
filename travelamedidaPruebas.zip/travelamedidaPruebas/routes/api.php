<?php


use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Api\AuthController;
use App\Http\Controllers\Api\ReservaController;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::middleware('auth:sanctum')->get('/user', function (Request $request) {
    return $request->user();
});

// Grupo de autenticación
Route::prefix('auth')->group(function () {
    // Autenticación tradicional
    Route::post('/register', [AuthController::class, 'register']);
    Route::post('/login', [AuthController::class, 'login']);
    
    // Autenticación con Google
    Route::post('/login/google', [AuthController::class, 'loginWithGoogle']);
    
    // Logout (protegido)
    Route::post('/logout', [AuthController::class, 'logout'])->middleware('auth:sanctum');

    // Confirmar Reserva (protegido)
    Route::post('/reserva/confirmar', [ReservaController::class, 'confirmar'])->middleware('auth:sanctum');
    Route::get('/reserva/{loc}', [ReservaController::class, 'showReserva'])->middleware('auth:sanctum');
    Route::get('/listaReservas/{pagina}', [ReservaController::class, 'listaReservas'])->middleware('auth:sanctum');
});

// Rutas protegidas (ejemplo)
Route::middleware('auth:sanctum')->group(function () {
    //Route::get('/profile', [ProfileController::class, 'show']);
    // Otras rutas protegidas...
   
});