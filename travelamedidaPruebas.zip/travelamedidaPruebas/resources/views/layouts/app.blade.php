<!doctype html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="{{ csrf_token() }}">

    <title>{{ config('app.name', 'Laravel') }}</title>

    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.bunny.net">
    <link href="https://fonts.bunny.net/css?family=Nunito" rel="stylesheet">
    <!-- Vinculando el archivo CSS -->
    <link href="{{ asset('css/styles.css') }}" rel="stylesheet">
    <!-- Scripts -->
    @vite(['resources/sass/app.scss', 'resources/js/app.js'])


</head>
<body class="bg-neutral text-primary">
    <div id="app">
        <nav class="navbar navbar-expand-md bg-primary  shadow-sm">
            <div class="container">
                <a class="navbar-brand text-white font-bold" href="{{ url('/') }}">
                  
                    <img src="{{ asset('travel.svg') }}" alt="Logo" style="height: 80px;">
                </a>
                <button class="navbar-toggler text-neutral" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="{{ __('Toggle navigation') }}">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav me-auto">
                        <li class="nav-item">
                            <a class="nav-link border rounded text-white  hover:bg-danger" href="{{ url('/traslados') }}">Traslados</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link border rounded text-white  hover:text-neutral" href="{{ url('/hoteles') }}">Hoteles</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link border rounded  text-white hover:text-accent" href="{{ url('/tours') }}">Tours</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link text-white hover:text-accent" href="{{ url('/carritos/show') }}">
                                <i class="fas fa-shopping-cart">Carrito</i> <!-- Ícono de carrito -->
                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="none" stroke="currentColor" viewBox="0 0 24 24" class="h-6 w-6">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 3h18l-1.29 9.09a2 2 0 0 1-1.98 1.91H7.27a2 2 0 0 1-1.98-1.91L3 3zm5.5 14a2.5 2.5 0 1 0 5 0 2.5 2.5 0 0 0-5 0zm8 0a2.5 2.5 0 1 0 5 0 2.5 2.5 0 0 0-5 0z"/>
                                </svg>

                            </a>
                        </li>
                        @auth
                        <li class="nav-item">
                            <a class="nav-link text-white hover:text-accent" href="{{ url('/reservas') }}">
                                <i class="fas fa-shopping-cart">Reservas</i> <!-- Ícono de carrito -->
                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" viewBox="0 0 24 24">
                                    <path d="M6 3h12a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2z" />
                                    <path d="M9 7h6M9 11h6M9 15h4" />
                                </svg>
                            </a>
                        </li>
                        @endauth
                    </ul>

                    <ul class="navbar-nav ms-auto">
                        @guest
                            @if (Route::has('login'))
                                <li class="nav-item">
                                    <a class="nav-link text-white hover:text-accent" href="{{ route('login') }}">{{ __('Login') }}</a>
                                </li>
                            @endif

                            @if (Route::has('register'))
                                <li class="nav-item">
                                    <a class="nav-link text-neutral text-white hover:text-accent" href="{{ route('register') }}">{{ __('Register') }}</a>
                                </li>
                            @endif
                        @else
                            <li class="nav-item dropdown">
                                <a id="navbarDropdown" class="nav-link dropdown-toggle text-white hover:text-accent" href="#" role="button" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                                    {{ Auth::user()->name }}
                                </a>

                                <div class="dropdown-menu dropdown-menu-end bg-primary" aria-labelledby="navbarDropdown">
                                    <a class="dropdown-item text-neutral hover:text-accent" href="{{ route('logout') }}"
                                       onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                        {{ __('Logout') }}
                                    </a>

                                    <form id="logout-form" action="{{ route('logout') }}" method="POST" class="d-none">
                                        @csrf
                                    </form>
                                </div>
                            </li>
                        @endguest
                    </ul>
                </div>
            </div>
        </nav>
                
        <main class="py-4 bg-neutral">
            <div class="container mx-auto p-4 bg-white shadow rounded-lg">
                @yield('content')
            </div>
        </main>
    </div>
</body>
</html>
