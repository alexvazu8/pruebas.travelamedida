<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class CarritosController extends Controller
{
    //hacer la funcion show
    public function show()
    {
        //usar ApiController
        $apiController = new ApiController();
        $response = $apiController->showCarrito();
        if (!$response->successful()) {
            //dd($request);
            // Procesar los datos obtenidos de la API
            //aqui no fue satisfactorio, hay errores:
            $jsonResponse= response()->json($response->json());
            $data = json_decode($jsonResponse->getContent(), true);


            return view('carritos.show', ['respuestas' => $data,'mensaje'=>'Error o Carrito vacio.!!!']);
        } else {
            $jsonResponse= response()->json($response->json());
            //print_r(response()->json($jsonResponse));
            $data = json_decode($jsonResponse->getContent(), true);
             //dd($data);
           
            return view('carritos.show', ['respuestas' => $data,'mensaje'=>'Exito!!!']);
        
        } 
    }

    //Funcion Delete

    public function borrar()
    {
        //usar ApiController
        $apiController = new ApiController();
        $response = $apiController->borrarCarrito();
        if (!$response->successful()) {
            //dd($request);
            // Procesar los datos obtenidos de la API
            //aqui no fue satisfactorio, hay errores:
            $jsonResponse= response()->json($response->json());
            $data = json_decode($jsonResponse->getContent(), true);


            return view('carritos.show', ['respuestas' => $data,'mensaje'=>'Error o Carrito vacio.!!!']);
        } else {
            $jsonResponse= response()->json($response->json());
            //print_r(response()->json($jsonResponse));
            $data = json_decode($jsonResponse->getContent(), true);
             //dd($data);
           
            return view('carritos.show', ['respuestas' => $data,'mensaje'=>'Carrito Vacio!!!']);
        
        } 
    }
    

}
